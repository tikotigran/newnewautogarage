import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateRepairTotals,
  calculateExpenseTotals,
  calculateVehicleFinancials,
  roundToTwo,
} from './finance';

test('roundToTwo rounds values accurately', () => {
  assert.equal(roundToTwo(10.556), 10.56);
  assert.equal(roundToTwo(10.551), 10.55);
});

test('calculateRepairTotals sums parts and labor separately and combined', () => {
  const repairs = [
    { partsCost: 120.5, laborCost: 80 },
    { partsCost: 45, laborCost: 55.5 },
  ];
  const totals = calculateRepairTotals(repairs);
  assert.equal(totals.partsTotal, 165.5);
  assert.equal(totals.laborTotal, 135.5);
  assert.equal(totals.total, 301);
});

test('calculateExpenseTotals sums non-repair general expenses', () => {
  const expenses = [
    { amount: 150 },
    { amount: 85 },
    { amount: 40.5 },
  ];
  assert.equal(calculateExpenseTotals(expenses), 275.5);
});

test('calculateVehicleFinancials calculates total capital invested, net profit, margin & ROI', () => {
  // Vehicle bought for 7500€
  // Repairs: 140€ parts + 90€ labor = 230€
  // Expenses: 150€ transport + 85€ CT = 235€
  // Total expenses = 465€
  // Total invested = 7500 + 465 = 7965€
  // Sold for 9800€
  // Net profit = 9800 - 7965 = 1835€
  // Margin % = (1835 / 9800) * 100 = 18.72%
  // ROI % = (1835 / 7965) * 100 = 23.04%
  const summary = calculateVehicleFinancials({
    purchasePrice: 7500,
    finalSalePrice: 9800,
    repairs: [
      { partsCost: 80, laborCost: 50 },
      { partsCost: 60, laborCost: 40 },
    ],
    expenses: [
      { amount: 150 },
      { amount: 85 },
    ],
  });

  assert.equal(summary.repairPartsTotal, 140);
  assert.equal(summary.repairLaborTotal, 90);
  assert.equal(summary.repairCostTotal, 230);
  assert.equal(summary.generalExpensesTotal, 235);
  assert.equal(summary.totalExpenses, 465);
  assert.equal(summary.totalInvested, 7965);
  assert.equal(summary.netProfit, 1835);
  assert.equal(summary.marginPercentage, 18.72);
  assert.equal(summary.roiPercentage, 23.04);
});

test('calculateVehicleFinancials falls back to targetSalePrice if not yet sold', () => {
  const summary = calculateVehicleFinancials({
    purchasePrice: 5000,
    targetSalePrice: 7000,
    repairs: [{ partsCost: 200, laborCost: 100 }],
    expenses: [{ amount: 100 }],
  });

  assert.equal(summary.totalExpenses, 400);
  assert.equal(summary.totalInvested, 5400);
  assert.equal(summary.netProfit, 1600);
  assert.equal(summary.marginPercentage, 22.86);
});
