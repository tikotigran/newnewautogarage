/**
 * Pure financial calculation utilities for AutoGarage Manager.
 * Handles auto-aggregation of repair parts, outsourced labor, general expenses,
 * total capital invested, net profit / margin, and ROI percentages.
 */

export interface RepairItem {
  partsCost: number;
  laborCost: number;
}

export interface ExpenseItem {
  amount: number;
}

export interface FinancialSummary {
  repairPartsTotal: number;
  repairLaborTotal: number;
  repairCostTotal: number;
  generalExpensesTotal: number;
  totalExpenses: number;
  totalInvested: number;
  effectiveSalePrice: number;
  netProfit: number;
  marginPercentage: number;
  roiPercentage: number;
}

export function roundToTwo(num: number): number {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}

export function calculateRepairTotals(repairs: RepairItem[] = []): {
  partsTotal: number;
  laborTotal: number;
  total: number;
} {
  const partsTotal = repairs.reduce((acc, r) => acc + (Number(r.partsCost) || 0), 0);
  const laborTotal = repairs.reduce((acc, r) => acc + (Number(r.laborCost) || 0), 0);
  return {
    partsTotal: roundToTwo(partsTotal),
    laborTotal: roundToTwo(laborTotal),
    total: roundToTwo(partsTotal + laborTotal),
  };
}

export function calculateExpenseTotals(expenses: ExpenseItem[] = []): number {
  const total = expenses.reduce((acc, e) => acc + (Number(e.amount) || 0), 0);
  return roundToTwo(total);
}

export function calculateVehicleFinancials(params: {
  purchasePrice: number;
  targetSalePrice?: number;
  finalSalePrice?: number;
  repairs?: RepairItem[];
  expenses?: ExpenseItem[];
}): FinancialSummary {
  const purchasePrice = Number(params.purchasePrice) || 0;
  const repairs = params.repairs || [];
  const expenses = params.expenses || [];

  const repairTotals = calculateRepairTotals(repairs);
  const generalExpensesTotal = calculateExpenseTotals(expenses);
  const totalExpenses = roundToTwo(repairTotals.total + generalExpensesTotal);
  const totalInvested = roundToTwo(purchasePrice + totalExpenses);

  const effectiveSalePrice = params.finalSalePrice !== undefined && params.finalSalePrice > 0
    ? Number(params.finalSalePrice)
    : (Number(params.targetSalePrice) || 0);

  const netProfit = effectiveSalePrice > 0
    ? roundToTwo(effectiveSalePrice - totalInvested)
    : 0;

  const marginPercentage = effectiveSalePrice > 0
    ? roundToTwo((netProfit / effectiveSalePrice) * 100)
    : 0;

  const roiPercentage = totalInvested > 0 && effectiveSalePrice > 0
    ? roundToTwo((netProfit / totalInvested) * 100)
    : 0;

  return {
    repairPartsTotal: repairTotals.partsTotal,
    repairLaborTotal: repairTotals.laborTotal,
    repairCostTotal: repairTotals.total,
    generalExpensesTotal,
    totalExpenses,
    totalInvested,
    effectiveSalePrice,
    netProfit,
    marginPercentage,
    roiPercentage,
  };
}

export function formatEuro(amount: number): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(amount);
}
