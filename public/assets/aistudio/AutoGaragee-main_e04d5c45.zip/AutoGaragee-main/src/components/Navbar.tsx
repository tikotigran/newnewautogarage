import React from 'react';
import {
  Car,
  Wrench,
  Smartphone,
  Monitor,
  Database,
  TrendingUp,
  DollarSign,
  PlusCircle,
  LogIn,
  LogOut,
  Sparkles,
  ShieldAlert,
  Building2,
  Settings,
  ExternalLink,
  Globe,
} from 'lucide-react';
import { Vehicle } from '../types/garage';
import { formatEuro } from '../utils/finance';
import { User, signInWithPopup, googleProvider, auth, signOut, signInAnonymously } from '../services/firebase';
import { useI18n } from '../i18n/I18nContext';

interface NavbarProps {
  vehicles: Vehicle[];
  user: User | null;
  activeView: 'desktop' | 'mobile';
  setActiveView: (view: 'desktop' | 'mobile') => void;
  onNewVehicle: () => void;
  onSeedData: () => void;
  isSeeding: boolean;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  vehicles,
  user,
  activeView,
  setActiveView,
  onNewVehicle,
  onSeedData,
  isSeeding,
}) => {
  const { lang, setLang, t } = useI18n();

  // Aggregate fleet stats
  const totalVehicles = vehicles.length;
  const inStock = vehicles.filter((v) => v.status !== 'sold').length;
  const totalInvested = vehicles.reduce((sum, v) => sum + (v.totalInvested || 0), 0);
  const totalProfit = vehicles.reduce((sum, v) => sum + (v.netProfit || 0), 0);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.warn('Google sign-in popup skipped, falling back to local garage session:', err);
      try {
        await signInAnonymously(auth);
      } catch (anonErr) {
        console.error('Sign in error:', anonErr);
      }
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-xl">
      {/* Top Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-600 to-red-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Car className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-amber-200 bg-clip-text text-transparent">
                  {t('appName')}
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {t('proDealer')}
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {t('appSubtitle')}
              </p>
            </div>
          </div>

          {/* View Switcher: Desktop vs React Native Mobile Simulator */}
          <div className="flex items-center bg-slate-800/90 p-1 rounded-xl border border-slate-700/80 shadow-inner">
            <button
              onClick={() => setActiveView('desktop')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'desktop'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>{t('studioView')}</span>
            </button>
            <button
              onClick={() => setActiveView('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'mobile'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>{t('mobileView')}</span>
            </button>
          </div>

          {/* Action Buttons, Language Switcher & Auth */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Language Switcher (FR / RU) */}
            <div className="flex items-center bg-slate-800/90 p-0.5 rounded-xl border border-slate-700/80 shadow-inner">
              <button
                type="button"
                onClick={() => setLang('fr')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  lang === 'fr'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Passer en Français"
              >
                <span>🇫🇷</span>
                <span className="hidden sm:inline">FR</span>
              </button>
              <button
                type="button"
                onClick={() => setLang('ru')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  lang === 'ru'
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Переключить на русский язык"
              >
                <span>🇷🇺</span>
                <span className="hidden sm:inline">RU</span>
              </button>
            </div>

            {totalVehicles === 0 && (
              <button
                onClick={onSeedData}
                disabled={isSeeding}
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-colors"
                title="Charger un parc exemple"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isSeeding ? t('loading') : t('demoFleet')}</span>
              </button>
            )}

            <button
              onClick={onNewVehicle}
              className="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md shadow-amber-500/20 transition-all transform active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t('newVehicle')}</span>
            </button>

            <a
              href={typeof window !== 'undefined' ? window.location.href : '#'}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
              title="Ouvrir dans un nouvel onglet"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">{t('openNewTab')}</span>
            </a>

            {user ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-700">
                <div
                  className="w-8 h-8 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center text-xs font-bold text-amber-400 overflow-hidden"
                  title={user.email || 'Garage User'}
                >
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" />
                  ) : (
                    (user.displayName?.[0] || user.email?.[0] || 'G').toUpperCase()
                  )}
                </div>
                <button
                  onClick={() => signOut(auth)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                  title={t('signOut')}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleLogin}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t('signIn')}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Real-time Fleet Performance Metrics Ribbon */}
      <div className="bg-slate-950/80 border-t border-slate-800/80 px-4 sm:px-6 lg:px-8 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-y-2 gap-x-4">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">{t('totalFleet')}</span>
              <span className="font-bold text-white">{t('vehiclesCount', { count: totalVehicles })}</span>
              <span className="text-slate-500">{t('activeStock', { count: inStock })}</span>
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <span className="text-slate-400">{t('capitalInvested')}</span>
              <span className="font-bold text-amber-400">{formatEuro(totalInvested)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-400">{t('globalMargin')}</span>
              <span className={`font-bold flex items-center gap-0.5 ${totalProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                <TrendingUp className="w-3.5 h-3.5" />
                {totalProfit >= 0 ? '+' : ''}{formatEuro(totalProfit)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span className="inline-flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              {t('liveSync')}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
