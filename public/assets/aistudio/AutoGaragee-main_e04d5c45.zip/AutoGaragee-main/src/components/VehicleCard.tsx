import React from 'react';
import {
  Wrench,
  TrendingUp,
  Calendar,
  Gauge,
  Tag,
  DollarSign,
  CheckCircle2,
  Clock,
  ArrowRight,
  FileText,
  AlertCircle,
  Truck,
  Image as ImageIcon,
} from 'lucide-react';
import { Vehicle, VehicleStatus } from '../types/garage';
import { formatEuro } from '../utils/finance';
import { useI18n } from '../i18n/I18nContext';

interface VehicleCardProps {
  vehicle: Vehicle;
  onSelect: (vehicle: Vehicle) => void;
  onQuickStatusChange: (vehicleId: string, newStatus: VehicleStatus) => void;
  onOpenSellModal: (vehicle: Vehicle) => void;
}

export const VehicleCard: React.FC<VehicleCardProps> = ({
  vehicle,
  onSelect,
  onQuickStatusChange,
  onOpenSellModal,
}) => {
  const { t, lang } = useI18n();

  const getStatusBadge = (status: VehicleStatus) => {
    switch (status) {
      case 'preparation':
        return {
          label: t('statusPreparation'),
          bg: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
          dot: 'bg-amber-400',
        };
      case 'repair':
        return {
          label: t('statusRepair'),
          bg: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
          dot: 'bg-blue-400',
        };
      case 'for_sale':
        return {
          label: t('statusForSale'),
          bg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
          dot: 'bg-emerald-400',
        };
      case 'sold':
        return {
          label: t('statusSold'),
          bg: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
          dot: 'bg-purple-400',
        };
      default:
        return {
          label: status,
          bg: 'bg-slate-700 text-slate-300 border-slate-600',
          dot: 'bg-slate-400',
        };
    }
  };

  const statusBadge = getStatusBadge(vehicle.status);
  const isSold = vehicle.status === 'sold';
  const effectivePrice = isSold && vehicle.buyerInfo?.salePrice
    ? vehicle.buyerInfo.salePrice
    : vehicle.targetSalePrice;

  const photoUrl = vehicle.photos && vehicle.photos.length > 0
    ? vehicle.photos[0]
    : 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80';

  return (
    <div
      onClick={() => onSelect(vehicle)}
      className="group bg-slate-900/90 rounded-2xl border border-slate-800 hover:border-amber-500/50 shadow-lg hover:shadow-2xl hover:shadow-amber-500/5 transition-all duration-300 overflow-hidden flex flex-col cursor-pointer"
    >
      {/* Top Image Preview with Overlaid Badges */}
      <div className="relative h-44 w-full bg-slate-950 overflow-hidden">
        <img
          src={photoUrl}
          alt={`${vehicle.make} ${vehicle.model}`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>

        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border backdrop-blur-md ${statusBadge.bg}`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${statusBadge.dot}`}></span>
            {statusBadge.label}
          </span>
        </div>

        {/* VIN / Plate tag */}
        <div className="absolute top-3 right-3">
          <span className="px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-slate-900/90 text-slate-300 border border-slate-700/80 shadow">
            {vehicle.vin}
          </span>
        </div>

        {/* Bottom overlay: Make, Model & Year */}
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight group-hover:text-amber-400 transition-colors">
              {vehicle.make} {vehicle.model}
            </h3>
            <p className="text-xs text-slate-300 font-medium truncate max-w-[240px]">
              {vehicle.trim || 'Standard'}
            </p>
          </div>
          <span className="px-2 py-0.5 rounded text-xs font-bold bg-amber-500 text-slate-950 shadow">
            {vehicle.year}
          </span>
        </div>
      </div>

      {/* Body: Key Specifications */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
        {/* Specs row */}
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
          <div className="flex items-center gap-1.5">
            <Gauge className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-200 font-semibold">
              {vehicle.mileage.toLocaleString(lang === 'ru' ? 'ru-RU' : 'fr-FR')} km
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-300">
              {t('boughtOn')} {vehicle.purchaseDate}
            </span>
          </div>
        </div>

        {/* Financial Ledger Snapshot */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">{t('purchaseAndExpenses')}</span>
            <span className="text-slate-200 font-bold">
              {formatEuro(vehicle.purchasePrice)} + {formatEuro(vehicle.totalExpenses)} ={' '}
              <span className="text-amber-300">{formatEuro(vehicle.totalInvested)}</span>
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">
              {isSold ? t('realizedSalePrice') : t('targetSalePrice')}
            </span>
            <span className="text-white font-extrabold text-sm">
              {formatEuro(effectivePrice)}
            </span>
          </div>

          {/* Net Margin & ROI Box */}
          <div
            className={`p-2.5 rounded-xl border flex items-center justify-between ${
              vehicle.netProfit >= 0
                ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                : 'bg-red-950/30 border-red-500/30 text-red-300'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs font-semibold">{t('netMargin')}</span>
            </div>
            <div className="text-right">
              <div className="text-sm font-extrabold">
                {vehicle.netProfit >= 0 ? '+' : ''}{formatEuro(vehicle.netProfit)}
              </div>
              <div className="text-[10px] opacity-80 font-mono">
                {t('marginPercent', { val: vehicle.marginPercentage.toFixed(1) })}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Action Footer */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
          {/* Quick status selector */}
          <select
            value={vehicle.status}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => {
              const newStatus = e.target.value as VehicleStatus;
              if (newStatus === 'sold' && vehicle.status !== 'sold') {
                onOpenSellModal(vehicle);
              } else {
                onQuickStatusChange(vehicle.id, newStatus);
              }
            }}
            className="text-xs font-semibold bg-slate-800 text-slate-200 rounded-lg px-2.5 py-1.5 border border-slate-700 hover:border-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer"
          >
            <option value="preparation">🛠️ {t('statusPreparation')}</option>
            <option value="repair">🔧 {t('statusRepair')}</option>
            <option value="for_sale">🏷️ {t('statusForSale')}</option>
            <option value="sold">✅ {t('statusSold')}</option>
          </select>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelect(vehicle);
            }}
            className="flex items-center gap-1 text-xs font-bold text-amber-400 group-hover:text-amber-300 transition-colors"
          >
            <span>{t('manageDossier')}</span>
            <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
};
