import React, { useState, useEffect } from 'react';
import {
  Navbar,
} from './components/Navbar';
import { VehicleList } from './components/VehicleList';
import { VehicleDetail } from './components/VehicleDetail';
import { VehicleModal } from './components/VehicleModal';
import { BuyerModal } from './components/BuyerModal';
import { MobileSimulator } from './components/MobileSimulator';
import { Vehicle, VehicleStatus, BuyerInfo } from './types/garage';
import {
  auth,
  onAuthStateChanged,
  signInAnonymously,
  User,
} from './services/firebase';
import {
  subscribeVehicles,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  seedDemoGarageData,
} from './services/garageService';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [activeView, setActiveView] = useState<'desktop' | 'mobile'>('desktop');

  // Modals state
  const [isVehicleModalOpen, setIsVehicleModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [isBuyerModalOpen, setIsBuyerModalOpen] = useState(false);
  const [sellingVehicle, setSellingVehicle] = useState<Vehicle | null>(null);
  const [isSeeding, setIsSeeding] = useState(false);

  // Initialize Auth
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        setUser(null);
      }
      setAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  const effectiveUserId = user?.uid || 'garage_pro_dealer';

  // Subscribe to real-time vehicles
  useEffect(() => {
    if (!authReady) return;

    const unsubscribe = subscribeVehicles(effectiveUserId, (data) => {
      setVehicles(data);

      // Keep selected vehicle in sync if updated
      setSelectedVehicle((prev) => {
        if (!prev) return null;
        return data.find((v) => v.id === prev.id) || null;
      });
    });

    return () => unsubscribe();
  }, [authReady, effectiveUserId]);

  // Seed demo data handler
  const handleSeedData = async () => {
    try {
      setIsSeeding(true);
      await seedDemoGarageData(effectiveUserId);
    } catch (err) {
      console.error('Seed demo error:', err);
    } finally {
      setIsSeeding(false);
    }
  };

  // Quick status change
  const handleQuickStatusChange = async (vehicleId: string, newStatus: VehicleStatus) => {
    await updateVehicle(vehicleId, { status: newStatus });
  };

  // Open sell modal
  const handleOpenSellModal = (vehicle: Vehicle) => {
    setSellingVehicle(vehicle);
    setIsBuyerModalOpen(true);
  };

  // Confirm sale
  const handleConfirmSale = async (vehicleId: string, buyerInfo: BuyerInfo) => {
    const targetVehicle = vehicles.find((v) => v.id === vehicleId);
    if (!targetVehicle) return;

    const netProfit = Number(buyerInfo.salePrice) - (targetVehicle.totalInvested || 0);
    const marginPercentage =
      Number(buyerInfo.salePrice) > 0 ? (netProfit / Number(buyerInfo.salePrice)) * 100 : 0;

    await updateVehicle(vehicleId, {
      status: 'sold',
      buyerInfo,
      netProfit,
      marginPercentage,
    });
  };

  // Create or Update vehicle
  const handleSaveVehicle = async (data: Omit<Vehicle, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingVehicle) {
      await updateVehicle(editingVehicle.id, data);
      setEditingVehicle(null);
    } else {
      const newId = await createVehicle(data);
      const created = vehicles.find((v) => v.id === newId);
      if (created) setSelectedVehicle(created);
    }
  };

  // Delete vehicle
  const handleDeleteVehicle = async (vehicleId: string) => {
    await deleteVehicle(vehicleId);
    setSelectedVehicle(null);
  };

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white space-y-4">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        <p className="text-sm font-semibold text-slate-400">
          Initialisation sécurisée d'AutoGarage Manager...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        vehicles={vehicles}
        user={user}
        activeView={activeView}
        setActiveView={setActiveView}
        onNewVehicle={() => {
          setEditingVehicle(null);
          setIsVehicleModalOpen(true);
        }}
        onSeedData={handleSeedData}
        isSeeding={isSeeding}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeView === 'mobile' ? (
          <MobileSimulator
            vehicles={vehicles}
            userId={effectiveUserId}
            onOpenVehicleModal={() => {
              setEditingVehicle(null);
              setIsVehicleModalOpen(true);
            }}
          />
        ) : selectedVehicle ? (
          <VehicleDetail
            vehicle={selectedVehicle}
            onBack={() => setSelectedVehicle(null)}
            onOpenEdit={(v) => {
              setEditingVehicle(v);
              setIsVehicleModalOpen(true);
            }}
            onOpenSellModal={handleOpenSellModal}
            onDeleteVehicle={handleDeleteVehicle}
            userId={effectiveUserId}
          />
        ) : (
          <VehicleList
            vehicles={vehicles}
            onSelectVehicle={(v) => setSelectedVehicle(v)}
            onNewVehicle={() => {
              setEditingVehicle(null);
              setIsVehicleModalOpen(true);
            }}
            onQuickStatusChange={handleQuickStatusChange}
            onOpenSellModal={handleOpenSellModal}
            onSeedData={handleSeedData}
            isSeeding={isSeeding}
          />
        )}
      </main>

      {/* Vehicle Add / Edit Modal */}
      <VehicleModal
        isOpen={isVehicleModalOpen}
        onClose={() => {
          setIsVehicleModalOpen(false);
          setEditingVehicle(null);
        }}
        onSubmit={handleSaveVehicle}
        initialVehicle={editingVehicle}
        userId={effectiveUserId}
      />

      {/* Buyer Info & Sale Closing Modal */}
      <BuyerModal
        isOpen={isBuyerModalOpen}
        onClose={() => {
          setIsBuyerModalOpen(false);
          setSellingVehicle(null);
        }}
        vehicle={sellingVehicle}
        onConfirmSale={handleConfirmSale}
      />
    </div>
  );
}
